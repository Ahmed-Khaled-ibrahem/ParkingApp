import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:parking/bloc/app_bloc/app_bloc.dart';
import 'package:latlong2/latlong.dart';

class BottomSheetDetail extends StatelessWidget {
  const BottomSheetDetail({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AppBloc, AppState>(
      builder: (context, state) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
          child: ListView.builder(
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return ListTile(
                onTap: (){
                  var lat = context.read<AppBloc>().data!.children.elementAt(index).children.firstWhere((element) => element.key == 'lat').value;
                  var lng = context.read<AppBloc>().data!.children.elementAt(index).children.firstWhere((element) => element.key == 'lng').value;
                  context.read<AppBloc>().destination = LatLng(double.parse(lat.toString()), double.parse(lng.toString()));

                  context.read<AppBloc>().add(NavigationStarted());
                  Navigator.pop(context);
                },
                leading: Icon(Icons.local_parking),
                title: Text(context
                    .read<AppBloc>()
                    .data!
                    .children
                    .elementAt(index)
                    .key
                    .toString()),
                subtitle: Text('Click to Navigate'),
                trailing: context
                    .read<AppBloc>()
                    .data!
                    .children
                    .elementAt(index)
                    .children
                    .firstWhere((element) => element.key == 'status')
                    .value
                    == 1 ? Icon(
                  Icons.event_available,
                  color: Colors.green,
                  size: 40,
                ):Icon(
                  Icons.event_busy_rounded,
                  color: Colors.red,
                  size: 40,
                ),
              );
            },
            itemCount: context.read<AppBloc>().data?.children.length,
          ),
        );
      },
    );
  }
}
