
class LineString {
  LineString(this.lineString);
  List<dynamic> lineString;
}